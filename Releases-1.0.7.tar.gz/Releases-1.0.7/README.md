# Releases
## **If you are having an issue DO NOT open an issue on this repo instead join the [discord](https://prax.wtf/discord)**
## [Download](https://github.com/Prax-Client/Releases/releases/latest)

## Info:
This is the official repository for Prax Client free releases
